import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'TEXTOPIA · 나의 독서마을', description: '읽은 책이 집이 되고, 나의 문장이 풍경이 되는 3D 독서마을.' };
export default function RootLayout({children}:Readonly<{children:React.ReactNode}>){return <html lang="ko"><body>{children}</body></html>}
